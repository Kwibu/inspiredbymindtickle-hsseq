
window.addEventListener("DOMContentLoaded", loadAdminTable);

async function loadAdminTable() {
  const response = await fetch("https://script.google.com/macros/s/AKfycbzSHUSBRiMZmnO0IPcDvzTsgiHRypijvWooYF6t2Ut-7oCAK-fO9pgdXsVZ4t1PUwUn/exec?admin=1");
  const data = await response.json();

  const tbody = document.querySelector("#adminTable tbody");
  data.forEach(row => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${row["Driver Name"]}</td>
      <td>${row["Truck"]}</td>
      <td>${row["Language"]}</td>
      <td>${row["Video Title"]}</td>
      <td>${row["Status"]}</td>
      <td>${row["Start Time"] || ""}</td>
      <td>${row["Completion Time"] || ""}</td>
      <td>${row["Duration"] || ""}</td>
    `;
    tbody.appendChild(tr);
  });
}
